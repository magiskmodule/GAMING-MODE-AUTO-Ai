- Introduction -

- Gaming-Mode | Magisk Module -

--------------------------------------------
╭━━━╮╱╱╱╱╱╱╱╱╱╱╱╱╭╮╱╭╮╱╱╱╱╱╱╭━╮╱╭╮╱╱╱╭╮╱╱╱╱╱╱╱╭╮╱╱╱╭╮"
┃╭━╮┃╱╱╱╱╱╱╱╱╱╱╱╱┃┃╱┃┃╱╱╱╱╱╱┃┃╰╮┃┃╱╱╱┃┃╱╱╱╱╱╱╭╯╰╮╱╱┃┃"
┃┃╱╰╋━━┳╮╭┳━━┳━━╮┃╰━╯┣━━┳━━╮┃╭╮╰╯┣━━╮┃┃╱╱╭┳╮╭╋╮╭╋━━┫┃"
┃┃╭━┫╭╮┃╰╯┃┃━┫━━┫┃╭━╮┃╭╮┃━━┫┃┃╰╮┃┃╭╮┃┃┃╱╭╋┫╰╯┣┫┃┃━━╋╯"
┃╰┻━┃╭╮┃┃┃┃┃━╋━━┃┃┃╱┃┃╭╮┣━━┃┃┃╱┃┃┃╰╯┃┃╰━╯┃┃┃┃┃┃╰╋━━┣╮"
╰━━━┻╯╰┻┻┻┻━━┻━━╯╰╯╱╰┻╯╰┻━━╯╰╯╱╰━┻━━╯╰━━━┻┻┻┻┻┻━┻━━┻╯"
----------------------
- Features -
- Boost Game Performance When The Game Start
- Improve Touch Sensitivity
- Improve Network And Ping
- Unlock Game Graphics and FPS
----------------------------------------------------------
° By AkiraSuper °

Yes, works on all ROMs and on all firmwares.

✓ INSTALLATION: Just flash via Magisk and reboot

× Disclaimer ×

Naturally, you take all the responsibility for what happens to your device when you start messing around with things.
I (Akira) will not be responsible for ANY damage caused to anyone's devices due to the use of this module.
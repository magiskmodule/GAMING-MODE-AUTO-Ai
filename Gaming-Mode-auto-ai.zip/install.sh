#!/system/bin/sh

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=true

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=true

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

# Set what you want to display when installing your module

print_modname() {
  ui_print " "
  ui_print "╭━━━╮╱╱╱╱╱╱╱╱╱╱╱╱╭╮╱╭╮╱╱╱╱╱╱╭━╮╱╭╮╱╱╱╭╮╱╱╱╱╱╱╱╭╮╱╱╱╭╮"
  ui_print "┃╭━╮┃╱╱╱╱╱╱╱╱╱╱╱╱┃┃╱┃┃╱╱╱╱╱╱┃┃╰╮┃┃╱╱╱┃┃╱╱╱╱╱╱╭╯╰╮╱╱┃┃"
  ui_print "┃┃╱╰╋━━┳╮╭┳━━┳━━╮┃╰━╯┣━━┳━━╮┃╭╮╰╯┣━━╮┃┃╱╱╭┳╮╭╋╮╭╋━━┫┃"
  ui_print "┃┃╭━┫╭╮┃╰╯┃┃━┫━━┫┃╭━╮┃╭╮┃━━┫┃┃╰╮┃┃╭╮┃┃┃╱╭╋┫╰╯┣┫┃┃━━╋╯"
  ui_print "┃╰┻━┃╭╮┃┃┃┃┃━╋━━┃┃┃╱┃┃╭╮┣━━┃┃┃╱┃┃┃╰╯┃┃╰━╯┃┃┃┃┃┃╰╋━━┣╮"
  ui_print "╰━━━┻╯╰┻┻┻┻━━┻━━╯╰╯╱╰┻╯╰┻━━╯╰╯╱╰━┻━━╯╰━━━┻┻┻┻┻┻━┻━━┻╯"
  ui_print " "
  ui_print "• By AkiraSuper •"
  ui_print " "
}
  
on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2
  props=$TMPDIR/system.prop
  module=$TMPDIR/module.prop
  . $TMPDIR/addon/Volume-Key-Selector/preinstall.sh
  
  ui_print " "
  ui_print "  [Volume+] Next; [Volume-] Install"
  ui_print " "
  ui_print "---Game Unlocker Mode---"
  ui_print "    1. PUBG Mobile "
  ui_print "    2. COD Mobile And Asphalt 9: Legends "
  ui_print "    3. Don't Unlock "
  ui_print "   "
ui_print "  Select Unlocker:"
GM=1
while true; do
	ui_print "  $GM"
	if $VKSEL; then
		GM=$((GM + 1))
	else 
		break
	fi
	if [ $GM -gt 3 ]; then
		GM=1
	fi
done
ui_print "   "
ui_print "  Unlocker Mode: $GM"
#
case $GM in
	1 ) sed -i '/ro.product.model/s/.*/ro.product.model=IN2023/' $props; sed -i '/ro.product.system.model/s/.*/ro.product.system.model=IN2023/' $props; sed -i '/ro.product.vendor.model/s/.*/ro.product.vendor.model=IN2023/' $props; sed -i '/ro.product.odm.model/s/.*/ro.ro.product.odm.model=IN2023/' $props;;
	2 ) sed -i '/ro.product.model/s/.*/ro.product.model=SM-G965F/' $props; sed -i '/ro.product.system.model/s/.*/ro.product.system.model=SM-G965F/' $props; sed -i '/ro.product.vendor.model/s/.*/ro.product.vendor.model=SM-G965F/' $props; sed -i '/ro.product.odm.model/s/.*/ro.ro.product.odm.model=SM-G965F/' $props;;
	3 ) sed -i '/ro.product.model/s/.*/#ro.product.model/' $props; sed -i '/ro.product.system.model/s/.*/#ro.product.system.model/' $props; sed -i '/ro.product.vendor.model/s/.*/#ro.product.vendor.model/' $props; sed -i '/ro.product.odm.model/s/.*/#ro.ro.product.odm.model/' $props;;
esac

ui_print "   "
# Do install-time script execution
  if [ -e /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android ]; then
      sh "$MODPATH/pubgconfig/60_FPS-GL"
  fi
  if [ -e /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android ]; then
      sh "$MODPATH/pubgconfig/60_FPS-KR"
  fi
echo "- Gaming Mode Enable"
rm -rf $MODPATH/pubgconfig/60_FPS-GL
rm -rf $MODPATH/pubgconfig/60_FPS-KR
  }

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}
